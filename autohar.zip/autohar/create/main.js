const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
    container.classList.add("right-panel-active");
});

signInButton.addEventListener('click', () => {
    container.classList.remove("right-panel-active");
});

$(document).ready(function () {
    $("form").submit(function (event) {
        event.preventDefault(); 

        let form = $(this);
        let formData = form.serialize(); 
        let actionUrl = form.attr("action") || "/../apis/create.php"; 
        let submitButton = form.find("button[type='submit']");
        let originalButtonText = submitButton.html(); 

        submitButton.prop("disabled", true).html('<i class="fa fa-spinner fa-spin"></i> Creating...');

        $.ajax({
            type: "POST",
            url: actionUrl,
            data: formData,
            dataType: "json",
            success: function (response) {
                if (response.status == "success") {
                    toastr.success(response.message); 
                } else {
                    toastr.error(response.message);
                }
            },
            error: function (xhr) {
                let errorMessage = "Something went wrong.";
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }
                toastr.error(errorMessage);
            },
            complete: function () {
                submitButton.prop("disabled", false).html(originalButtonText);
            }
        });
    });
});
