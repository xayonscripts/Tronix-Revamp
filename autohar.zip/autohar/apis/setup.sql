/* just copy paste this in mysql phpmyadmin in the sql thing inside ur db*/
CREATE TABLE data(
        id INT AUTO_INCREMENT PRIMARY KEY,
        web VARCHAR(255) NOT NULL,
        dir VARCHAR(255) NOT NULL,
        type VARCHAR(255) NOT NULL,
        password VARCHAR(35) NOT NULL,
        summary VARCHAR(255) NOT NULL,
        views VARCHAR(255) NOT NULL,
        hits VARCHAR(255) NOT NULL
)