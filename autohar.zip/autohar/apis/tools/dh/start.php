<?php
$dh = '{dual}';
$type = $_GET['t']; 
$web = $_GET['web']; 
$dir = $_GET['dir']; 
$name = '{name}';
$thumb = '{thumb}';
$inv = '{invite}';

$data = array(
    'dh' => $dh,
    't' => $type,
    'web' => $web,
    'dir' => $dir,
    'name' => $name,
    'thumb' => $thumb,
    'dc' => $inv
);
$domain = $_SERVER['HTTP_HOST'];
$url = "http://$domain/apis/create.php"; 

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
echo $response;
?>
