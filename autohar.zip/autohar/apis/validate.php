<?php

if (isset($_POST['cookie'])) {
    $cookie = $_POST['cookie'];

    $apiUrl = 'https://users.roblox.com/v1/users/authenticated';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Cookie: .ROBLOSECURITY=' . $cookie, 
    ]);
    $response = curl_exec($ch);
    $httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpStatusCode === 200) {
        $userData = json_decode($response, true);
        echo json_encode([
            'status' => 'success',
            'user' => $userData
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid cookie or failed to authenticate.'
        ]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No cookie provided']);
}
?>
