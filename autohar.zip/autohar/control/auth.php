<?php
session_start();
include 'config.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['password'])) {
    $inputPassword = $_POST['password'];

    $stmt = $conn->prepare("SELECT id FROM data WHERE password = ?");
    $stmt->bind_param("s", $inputPassword);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($userID);
        $stmt->fetch();
        
        $_SESSION['user_id'] = $userID; 

        header("Location: dashboard.php");
        exit;
    } else {
        echo "Invalid password!";
    }

    $stmt->close();
}
$conn->close();
?>
