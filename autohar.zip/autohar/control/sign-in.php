<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In</title>
  <link href="https://cdn.jsdelivr.net/npm/daisyui@2.51.6/dist/full.css" rel="stylesheet" type="text/css" />
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .navbar {
      background-color: #000 !important;
      color: #fff !important; 
    }
    .main-content {
      background-color: #fff !important;
      color: #000 !important;
    }
    .btn-black {
      background-color: #000 !important; 
      color: #fff !important;
    }
    .btn-black:hover {
      background-color: #4b5563 !important;
    }
  </style>
</head>
<body class="flex flex-col min-h-screen">
  <nav class="navbar p-4 flex justify-between items-center">
    <div class="flex items-center">
      <svg class="w-8 h-8 mr-2" fill="none" stroke="white" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 11c0-2.21 1.79-4 4-4s4 1.79 4 4-1.79 4-4 4m-8 0c0-2.21-1.79-4-4-4S0 8.79 0 11s1.79 4 4 4m8 0v6m-4-6v6m8-6v6"></path>
      </svg>
      <h1 class="text-2xl" style="font-family: 'Anton', sans-serif;">Controller</h1>
    </div>
  </nav>

  <main class="main-content flex-1 flex items-center justify-center p-4">
    <div class="card bg-white shadow-xl w-full max-w-md">
      <div class="card-body">
        <h2 class="card-title text-2xl mb-4">Sign In</h2>
        <form action="auth.php" method="POST">
          <div class="form-control mb-6">
            <label class="label">
              <span class="label-text text-black">Password</span>
            </label>
            <input type="password" placeholder="Enter your password" class="input input-bordered w-full" name="password" required value="<?php $keyes = $_GET['key']; echo $keyes ?>"/>
          </div>
          <button class="btn btn-black w-full" type="submit">Sign In</button>
        </form>
      </div>
    </div>
  </main>
</body>
</html>
