
<?php

include (__DIR__ ."/../apis/config.php");
?>