<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: sign-in.php");
    exit;
}

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$stmt = $conn->prepare("SELECT web, dir, type, summary, views, hits, password FROM data WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($web, $dir, $type, $summary, $views, $hits, $password);
$stmt->fetch();
$stmt->close();

$leaderboardQuery = "SELECT dir AS username, hits FROM data ORDER BY hits DESC LIMIT 5";
$leaderboardResult = $conn->query($leaderboardQuery);

$leaderboard = [];
if ($leaderboardResult->num_rows > 0) {
    while ($row = $leaderboardResult->fetch_assoc()) {
        $leaderboard[] = $row;
    }
}

$newer = isset($_POST['new-web']) ? $_POST['new-web'] : null;

if ($newer) {
    function validateDiscordWebhook($webhook_url) {
        $ch = curl_init($webhook_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        
        $data = json_encode([
            'content' => 'Setting New Webhook <a:loading:1356735652489855128>'
        ]);
        
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 204) {
            return true;
        }
        return false;
    }

    if (validateDiscordWebhook($newer)) {
        $data = json_encode(['content' => '@everyone NEW WEBHOOK SET <:shield_success:1356735858920652866>']);
        $ch = curl_init($newer);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_exec($ch);
        curl_close($ch);

        $stmt = $conn->prepare("UPDATE data SET web = ? WHERE dir = ?");
        $stmt->bind_param("ss", $newer, $dir);
        $stmt->execute();
        $stmt->close();
    }
}

$conn->close();
?>




<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <title>Controller</title>
  <link href="https://cdn.jsdelivr.net/npm/daisyui@2.51.6/dist/full.css" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


  <style>
    .tab-content { display: none; }
    #tab-dashboard:checked ~ .container .main-content #dashboard,
    #tab-settings:checked ~ .container .main-content #settings {
      display: block;
    }
    .sidebar { background-color: black; color: white; }
    .sidebar label:hover { background-color: #4b5563; }
    .top-navbar { background-color: black; color: white; }
    .progress-bar { background-color: #333; }
    .main-content { 
      width: 100%; 
      max-width: calc(100% - 16rem);
    }
  </style>
</head>
<body>

  <input type="radio" id="tab-dashboard" name="tabs" checked class="hidden">
  <input type="radio" id="tab-settings" name="tabs" class="hidden">

  <div class="container flex flex-col min-h-screen">
    
    <nav class="top-navbar p-4 flex justify-between items-center">
      <h1 class="text-2xl">Controller</h1>
      <a href="logout.php" class="btn btn-ghost text-white">Logout</a>
    </nav>

    <div class="flex flex-1">
      <aside class="sidebar w-64 p-4">
        <label for="tab-dashboard" class="block p-2 cursor-pointer hover:bg-gray-700">Stats</label>
        <label for="tab-settings" class="block p-2 cursor-pointer hover:bg-gray-700">Settings</label>
      </aside>

      <main class="main-content p-4 bg-white text-black">
        
        <div id="dashboard" class="tab-content">
          
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div class="card bg-white shadow-xl">
              <div class="card-body">
                <h2 class="card-title">Hits</h2>
                <p class="text-3xl font-bold"><?php echo $hits; ?></p>
                <progress class="progress progress-bar w-full" value="<?php echo $hits; ?>"></progress>
              </div>
            </div>
            <div class="card bg-white shadow-xl">
              <div class="card-body">
                <h2 class="card-title">Views</h2>
                <p class="text-3xl font-bold"><?php echo $views; ?></p>
                <progress class="progress progress-bar w-full" value="<?php echo $views; ?>"></progress>
              </div>
            </div>
            <div class="card bg-white shadow-xl">
              <div class="card-body">
                <h2 class="card-title">Summary</h2>
                <p class="text-3xl font-bold"><?php echo $summary; ?></p>
                <progress class="progress progress-bar w-full" value="<?php echo $summary; ?>"></progress>
              </div>
            </div>
          </div>

          <div class="card bg-white shadow-xl mb-4">
            <div class="card-body">
              <h2 class="card-title">Leaderboard</h2>
              <div class="overflow-x-auto">
                <table class="table w-full">
                  <thead>
                    <tr>
                      <th>Rank</th>
                      <th>Hitter</th>
                      <th>Hits</th>
                    </tr>
                  </thead>
                  <tbody>
<?php
if (!empty($leaderboard)) {
    usort($leaderboard, function($a, $b) {
        return $b['hits'] - $a['hits'];
    });

    $rank = 1;
    foreach ($leaderboard as $user) {
        echo "<tr>
                <td>{$rank}</td>
                <td>" . htmlspecialchars($user['username']) . "</td>
                <td>{$user['hits']}</td>
              </tr>";
        $rank++;
    }
} else {
    echo "<tr><td colspan='3'>No data available</td></tr>";
}
?>

                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="card bg-white shadow-xl">
            <div class="card-body">
              <h2 class="card-title">Live Hits</h2>
              <div class="overflow-x-auto">
                <table class="table w-full">
                  <thead>
                    <tr>
                      <th>HIT</th>
                      <th>Username</th>
                      <th>Hitter</th>
                      <th>Robux</th>
                    </tr>
                  </thead>
                  <tbody id="liveHitsBody">
                    <tr><td colspan="4">Loading...</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>

         <div id="settings" class="tab-content">
          <div class="card bg-white shadow-xl">
            <div class="card-body">
              <h2 class="card-title">Autohar Settings</h2>
              <form  action="dashboard.php" method="POST">
  <div class="form-control">
    <label class="label">Set New Discord Webhook:</label>
    <input class="input input-bordered" placeholder="Enter new Webhook.." name="new-web" required type="url" />
  </div>
  <button type="submit" class="btn btn-black mt-4 w-full">Save</button>
</form>
            </div>
          </div>
        </div>

      </main>
    </div>
  </div>

  <script>
    async function fetchLiveHits() {
      try {
        const response = await fetch("live.php");
        const data = await response.json();

        if (data.error) {
          document.getElementById("liveHitsBody").innerHTML = `<tr><td colspan="4">${data.error}</td></tr>`;
          return;
        }

        const tableBody = document.getElementById("liveHitsBody");
        tableBody.innerHTML = "";

        data.forEach(hit => {
          const row = `
            <tr>
              <td>
                <div class="avatar">
                  <div class="w-10 rounded-full">
                    <img src="${hit.avatar}" alt="Profile Picture" />
                  </div>
                </div>
              </td>
              <td>${hit.rbxname}</td>
              <td>${hit.hitter}</td>
              <td>${hit.robux}</td>
            </tr>
          `;
          tableBody.innerHTML += row;
        });

      } catch (error) {
        console.error("Error fetching data:", error);
      }
    }