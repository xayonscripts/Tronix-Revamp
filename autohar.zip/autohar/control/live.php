<?php
header("Content-Type: application/json");

if (!file_exists("data.txt")) {
    echo json_encode(["error" => "No data available."]);
    exit;
}

$data = file("data.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$output = [];

foreach ($data as $index => $line) {
    $parts = explode("|", $line);
    $parsed = [];
    
    foreach ($parts as $part) {
        $keyValue = explode(":", $part, 2);
        if (count($keyValue) == 2) {
            $parsed[trim($keyValue[0])] = trim($keyValue[1]);
        }
    }
    
    $output[] = [
        "row" => $index + 1,
        "hitter" => $parsed["hitter"] ?? "",
        "robux" => $parsed["robux"] ?? "",
        "rbxname" => $parsed["user"] ?? "",
        "avatar" => $parsed["url"] ?? ""
    ];
}

echo json_encode($output, JSON_PRETTY_PRINT);
?>
